AutoNumeric authors are:
- *BobKnothe* - Robert Knothe
- *AlexandreBonneau* - Alexandre Bonneau
- *rhyek* - Carlos Gonzales
- *neyestrabelli* - Ney Estrabelli
- *chery-qualset-hcd-ca-gov*
- *carlos-ghan* - Carlos Ghan
- *bcherny* - Boris Cherny
- *barvian* - Maxwell Barvian
- *kossnocorp* - Sasha Koss
- *mbiert* - Mic Biert
- *randoum*
- *abzainuddin* - Zaico
- *peterboccia* - Peter Boccia
- *zayter*
- *brunobatista* - Bruno Batista
- *jarinudom* - Jarin Udom
- *Raylehnhoff* - Raymond Lehnhoff
- *SvenTo*
- *CoryFoy* - Cory Foy

(ordered by [Github](https://github.com/autoNumeric/autoNumeric/graphs/contributors) on 2016-12-01)
